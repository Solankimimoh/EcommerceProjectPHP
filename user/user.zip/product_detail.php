<?php
error_reporting(E_ALL ^ E_DEPRECATED);

session_start(); //start session
 //include config file
include('includes/dbfunctions.php');
$db = new DB_FUNCTIONS();

$id=$_GET['id'];


if(isset($_SESSION["user_loged"]))
{
	$username=$_SESSION['user_loged'];

}
else
{

	?>

	<script type="text/javascript">

		window.location.href="index.php";

	</script>

	<?php

}

?>
<!DOCTYPE html>
<html>
<head>
	
	<title>Grocery :: My order</title>

	<script type="text/javascript" src="js/jquery-1.10.1.min.js"></script>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.theme.min.css" rel="stylesheet">
	<script type="text/javascript" src="js/jquery-1.10.1.min.js"></script>

	
<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
	window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
		d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
			_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
			$.src="//v2.zopim.com/?3p5ff2T819MfGSPDH0NktXPXS4kkScFO";z.t=+new Date;$.
			type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
		</script>
		<!--End of Zopim Live Chat Script-->

</head>
<body style="background-color: rgb(236, 233, 233);">

	<!-- Static navbar -->
	<nav style="z-index:99;" class="navbar navbar-default navbar-static-top">
		<div class="">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="font-size: 30px;color: rgb(87, 48, 232);" href="index.php">Grocery Deals</a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li ><a href="index.php">Home</a></li>
					
					
					<li role="presentation" class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
							Our Products<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<?php
							$category="SELECT * FROM `category`";

							$results=mysql_query($category);

							while ($row=mysql_fetch_row($results)) {
								?>

								<li><a href="category.php?id=<?php echo $row[0]; ?>"><?php echo $row[1]; ?></a></li>
								<?php
							}
							?>
						</ul>
					</li>

				</ul>
				<?php


				if(isset($_SESSION["user_loged"]))
				{
					$username=$_SESSION["user_loged"];
					?>
					<ul class="nav navbar-nav pull-right" style="margin-right: 20px;">
						<li role="presentation" class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
								<?php echo $_SESSION['user_loged']; ?><span class="caret"></span><span style="margin-right: 20px;" class="glyphicon glyphicon-user pull-left btn-md"></span>
							</a>
							<ul class="dropdown-menu">
								<li>
									<a href=""> My Promo Code |  <?php

										$promocode="SELECT `r_promo_code` FROM `registration` WHERE `r_email`='$username'";

										$result=mysql_query($promocode);

										echo mysql_result($result,0);
										?>
									</a></li>
									<li><a href="view_cart.php"> My Cart</a></li>
									<li><a href="my_order.php">My Orders</a></li>
									<li><a href="logout.php"> Logout </a></li>

								</ul>
							</li>
						</ul>
						<?php
					}
					else
					{
						?>

						<ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
							<li><a href="registration.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
							<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
						</ul>


						<?php


					}

					?>



				</div><!--/.nav-collapse -->
			</div>
		</nav>
		<!--End Top Navbar-->

		<div class="container">

			<div class="row">

				<div class="col-lg-12">

					<table class="table table-hover">
						<thead>

							<tr>

								<th>Product Image</th>
								<th>Qty</th>
								<th>Price</th>
								<th>Total</th>

							</tr>

						</thead>

						<tbody>

							<?php

							$get_order_detail="SELECT * FROM `user_order_product_detail` WHERE `o_id`='$id'";

							$result=mysql_query($get_order_detail);

							while ($row=mysql_fetch_row($result)) 
							{

								?>
								<tr>
									<td>
										<?php $productPhoto = $db->getproductPhoto($row[5]);?>

										<img src="../admin/images/products/medium/<?=str_replace("_P","",$productPhoto)?>" width="100px" height="100px" ></td>
										<td><?php echo $row[1]; ?></td>
										<td><?php echo $row[2]; ?></td>
										<td><?php echo $row[3]; ?></td>
									</tr>
									<?php
								}
								?>
							</tbody>

						</table>

					</div>

				</div>

			</div>


			<script src="js/jquery.js"></script>
			<script type="text/javascript" src="js/jquery-1.10.1.min.js"></script>
			<script src="js/bootstrap.min.js"></script>

		</body>
		</html>