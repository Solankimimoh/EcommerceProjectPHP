<div class="col-lg-12" style="background-color: rgb(162, 162, 162);text-align: center;color: black;">

<h5>Copyright &#169; 2016 Grocery Deals</h5>

</div>