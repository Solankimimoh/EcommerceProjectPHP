<div class="filter_search">
		<input type="text" name="search_prod" id="search_prod" placeholder="Enter Product Name" style="width:120px; margin-bottom:10px;" value="" />		
		<input type="button" name="btn_clear" class="clearButton"  value="clear"/>
</div>