<div class="different_filters_divbox">                                            
	<ul class="different_filters">
			
		<li>
			<input type="radio" name="price_range" id="price_range1" value="0-199" class="price_range"/>
			<label for="price_range1">Rs. 0 - Rs. 199</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range2" value="200-499" class="price_range"/>
			<label for="price_range2">Rs. 200 - Rs. 499</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range3" value="500-699" class="price_range"/>
			<label for="price_range3">Rs. 500 - Rs. 699</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range4" value="700-999" class="price_range"/>
			<label for="price_range4">Rs. 700 - Rs. 999</label>
		</li>
		<li>
			<input type="radio" name="price_range" id="price_range5" value="1000-100000" class="price_range"/>
			<label for="price_range5">Rs. 1000 Above</label>
		</li>
		
		
		
	</ul>
</div>