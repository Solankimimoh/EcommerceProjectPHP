<div class="filtersshow" style="display:none;">
         <div class="filter1">
                <a href="javascript:;"><span class="filter2" style="cursor:pointer;">Adidas &nbsp; <img src="images/close.png" /></span></a>
                <a href="javascript:;" class="clear_filters" style="display:none;">Clear All</a>
                
                <div class="clearfix"></div>
          </div>
</div>