<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

	<title>Checkout | Grocery</title>


<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
  window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
    d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
      _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
      $.src="//v2.zopim.com/?3p5ff2T819MfGSPDH0NktXPXS4kkScFO";z.t=+new Date;$.
      type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
    </script>
    <!--End of Zopim Live Chat Script-->

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css" >

	<!-- Optional theme -->
	<link rel="stylesheet" href="css/bootstrap-theme.min.css" >

	<!-- Latest compiled and minified JavaScript -->
	<script src="js/bootstrap.min.js" ></script>

	<script type="text/javascript" src="js/jquery-1.10.1.min.js"></script>
	<script src="js/jquery.js"></script>

	<?php
	include('includes/dbfunctions.php');
	include("includes/resize-class.php");
	$db = new DB_FUNCTIONS();


	if(isset($_SESSION["user_loged"]))
	{
   ?>

   <script type="text/javascript">

    window.location.href="payment.php";

  </script>

  <?php
}
else
{

}

?>

</head>
<body style="background-color: rgb(206, 206, 206);">
  <!-- Static navbar -->
  <nav style="z-index:99;" class="navbar navbar-default navbar-static-top">
    <div class="">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" style="font-size: 30px;color: rgb(87, 48, 232);" href="index.php">Grocery Deals</a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <li ><a href="index.php">Home</a></li>
          
          
          <li role="presentation" class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
              Our Products<span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
              <?php
              $category="SELECT * FROM `category`";

              $results=mysql_query($category);

              while ($row=mysql_fetch_row($results)) {
                ?>

                <li><a href="category.php?id=<?php echo $row[0]; ?>"><?php echo $row[1]; ?></a></li>
                <?php
              }
              ?>
            </ul>
          </li>

        </ul>
        <?php


        if(isset($_SESSION["user_loged"]))
        {
          $username=$_SESSION["user_loged"];
          ?>
          <ul class="nav navbar-nav pull-right" style="margin-right: 20px;">
            <li role="presentation" class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <?php echo $_SESSION['user_loged']; ?><span class="caret"></span><span style="margin-right: 20px;" class="glyphicon glyphicon-user pull-left btn-md"></span>
              </a>
              <ul class="dropdown-menu">
                <li>
                  <a href=""> My Promo Code |  <?php

                    $promocode="SELECT `r_promo_code` FROM `registration` WHERE `r_email`='$username'";

                    $result=mysql_query($promocode);

                    echo mysql_result($result,0);
                    ?>
                  </a></li>
                  <li><a href="view_cart.php"> My Cart</a></li>
                  <li><a href="my_order.php">My Orders</a></li>
                  <li><a href="logout.php"> Logout </a></li>

                </ul>
              </li>
            </ul>
            <?php
          }
          else
          {
            ?>

            <ul class="nav navbar-nav navbar-right" style="margin-right: 20px;">
              <li><a href="../vendor/index.php"><span class="glyphicon glyphicon-user"></span> Vendor</a></li>
              <li><a href="registration.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
              <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
            </ul>


            <?php


          }

          ?>



        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <!--End Top Navbar-->


    <div class="container">

      <h1 style="text-align: center;margin-bottom: 20px;">Choose your way </h1>

      <div class="row" style="text-align: center;">

       <div class="col-lg-6">

        <form method="post" action="guest_user.php">

          <div class="thumbnail" style="text-align: center;background-image: url('images/bg_one.jpg');background-position-x: -350px;background-position-y: -290px;">
           <img src="images/guest.png" alt="...">
           <div class="caption">
            <h3 style="color: white;">Pay as Guest</h3>
            <p style="color: white; font-size: 15px;">No Password require. Just fill address and pay amount</p>
            <p><input type="submit" class="btn btn-lg" name="guest_user" value="Getting Started" style="background-color: rgba(255, 255, 255, 0.92);"></input></p>
          </div>
        </div>
      </form>
    </div>


    <div class="col-lg-6">
      <div class="thumbnail" style="text-align: center;background-image: url('images/bg_one.jpg');background-position-x: -350px;background-position-y: -290px;">
       <img src="images/user.png" alt="...">
       <div class="caption">
        <h3 style="color: white;">Pay with Account</h3>
        <p style="color: white; font-size: 16px;">Login your account and easily pay amount with your account</p>
        <p><a href="login.php" class="btn btn-lg" role="button" style="background-color: rgba(255, 255, 255, 0.92);"> Getting Started</a></p>
      </div>
    </div>
  </div>



</div>

</div>
<div class="row">


  <?php include 'footer.php';  ?>


</div>
</body>
</html>